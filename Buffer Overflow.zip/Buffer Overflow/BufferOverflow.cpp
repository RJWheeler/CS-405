// BufferOverflow.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iomanip>
#include <iostream>
#include <limits>
#include <string>

int main()
{
  std::cout << "Buffer Overflow Example" << std::endl;

  // TODO: The user can type more than 20 characters and overflow the buffer, resulting in account_number being replaced -
  //  even though it is a constant and the compiler buffer overflow checks are on.
  //  You need to modify this method to prevent buffer overflow without changing the account_number
  //  variable, and its position in the declaration. It must always be directly before the variable used for input.
  //  You must notify the user if they entered too much data.

  // The account number must remain directly before the input variable.
  const std::string account_number = "CharlieBrown42";

  // The array holds 20 bytes: 19 characters plus the null terminator.
  char user_input[20];

  std::cout << "Enter a value: ";
  std::cin.getline(user_input, sizeof(user_input));

  // If the user enters more than 19 characters, getline sets failbit.
  // Clear the error and remove the remaining characters from the input
  // so they cannot cause problems with later processing.
  if (std::cin.fail())
  {
      std::cin.clear();
      std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');

      std::cout << "You entered too much data. Please enter 19 characters or fewer."
          << std::endl;
  }
  else
  {
      std::cout << "You entered: " << user_input << std::endl;
  }

  std::cout << "Account Number = " << account_number << std::endl;
}

// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu
